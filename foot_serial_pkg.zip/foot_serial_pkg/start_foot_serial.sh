#!/bin/bash
set -e

# 自动探测已安装的 ROS 2 发行版，避免写死 humble 导致开机启动失败。
if [[ -f /opt/ros/jazzy/setup.bash ]]; then
	source /opt/ros/jazzy/setup.bash
elif [[ -f /opt/ros/humble/setup.bash ]]; then
	source /opt/ros/humble/setup.bash
else
	echo "No supported ROS setup.bash found under /opt/ros" >&2
	exit 1
fi

source /home/jiang/foot_serial_pkg/install/setup.bash
cd /home/jiang/foot_serial_pkg
exec ros2 launch foot_serial_pkg foot_serial.launch.py