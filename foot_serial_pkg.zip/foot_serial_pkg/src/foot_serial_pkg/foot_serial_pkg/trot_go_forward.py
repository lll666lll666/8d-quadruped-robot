import math

import rclpy
from geometry_msgs.msg import Point
from rclpy.node import Node

"""
模块用途
--------
该节点用于“计算并发布四足机器人足端轨迹点”。

核心思路
--------
1. 用一个周期 ts 描述每条腿的往复运动。
2. 每条腿在一个周期里分成两段：
    - 摆动相（脚离地，向前摆）
    - 支撑相（脚着地，向后划）
3. 通过相位偏移实现 trot 对角腿配对：
    - FL 与 RR 同相
    - FR 与 RL 相差半周期
4. 计算出的 (x, z) 封装为 Point 发布（y 固定为 0）。

参数总览
--------
- Ts: 周期（秒）
- lambda_ratio: 摆动相占比（0~1）
- h: 摆动相抬脚高度偏移
- xs, xf: 一步中 x 方向起止点
- zs: z 方向基准高度
"""


class FootTrajectoryPublisher(Node):
    """四足足端轨迹发布器节点。"""

    def __init__(self) -> None:
        super().__init__('foot_trajectory_publisher')

        # ----------------------------
        # 1) 声明 ROS 参数（可运行中动态修改）
        # ----------------------------
        'self.declare_parameter'  # 声明参数，提供默认值和类型提示
        # 四条腿的话题名与发布频率
        self.declare_parameter('topic_fl', '/foot_position_fl')
        self.declare_parameter('topic_fr', '/foot_position_fr')
        self.declare_parameter('topic_rl', '/foot_position_rl')
        self.declare_parameter('topic_rr', '/foot_position_rr')
        self.declare_parameter('publish_rate_hz', 50.0)

        # 与 MATLAB 中 trajectory.m 对应的轨迹参数
        # 这些参数决定“步幅大小、抬脚高度、周期快慢”等运动外观。
        # Ts: 轨迹周期（秒）
        # lambda_ratio: 摆动相在周期中的比例（0~1），即摆动时间 = lambda_ratio * Ts
        # h: 摆动相中足端相对提升高度的振幅（该实现中为负值以匹配坐标系习惯）
        # xs: 起始 x（起始支撑脚位置）
        # xf: 结束 x（摆动结束位置）
        # zs: 初始 z（地面高度或基准高度）
        self.declare_parameter('Ts', 0.5)
        self.declare_parameter('lambda_ratio', 0.5)
        self.declare_parameter('h', -10.0)
        self.declare_parameter('xs', -20.0)
        self.declare_parameter('xf', 20.0)
        self.declare_parameter('zs', 120.0)

        # ----------------------------
        # 2) 读取参数并初始化发布器
        # ----------------------------
        topic_fl = self.get_parameter('topic_fl').value
        topic_fr = self.get_parameter('topic_fr').value
        topic_rl = self.get_parameter('topic_rl').value
        topic_rr = self.get_parameter('topic_rr').value
        rate = float(self.get_parameter('publish_rate_hz').value)

        # 维护“腿名 -> 发布器”的映射，后续统一循环发布。
        self.leg_publishers = {
            # 每条腿对应一个 Point 话题发布器，队列长度为 10
            'fl': self.create_publisher(Point, topic_fl, 10),
            'fr': self.create_publisher(Point, topic_fr, 10),
            'rl': self.create_publisher(Point, topic_rl, 10),
            'rr': self.create_publisher(Point, topic_rr, 10),
        }

        # trot 步态：FL/RR 同相，FR/RL 反相（半周期相移）
        # 这里的值是“比例”，真正时间偏移 = 比例 * Ts。
        self.leg_phase_offset_ratio = {
            'fl': 0.0,
            'rr': 0.0,
            'fr': 0.5,
            'rl': 0.5,
        }

        # ----------------------------
        # 3) 定时器：固定频率触发轨迹发布
        # ----------------------------
        # 记录节点启动时刻，用于后续计算 elapsed（经过时间）
        self.start_time = self.get_clock().now()

        # rate 非法时回退到 0.02s（50Hz）
        timer_period = 1.0 / rate if rate > 0.0 else 0.02
        # 定时器周期决定发布频率，回调函数里执行“计算 + 发布”
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.get_logger().info(
            f'Publishing trot trajectory at {rate:.1f} Hz: '
            f'FL={topic_fl}, FR={topic_fr}, RL={topic_rl}, RR={topic_rr}'
        )
    
    #############################################################
    # 根据“当前时间 + 相位偏移 + 轨迹参数”计算单条腿足端 (x, z)
    #############################################################
    def _compute_foot_position(self, elapsed: float, phase_offset: float, ts: float, lambda_ratio: float,
                                h: float, xs: float, xf: float, zs: float) -> tuple[float, float]:
        """返回单条腿在当前时刻的位置。

        参数说明：
        - elapsed: 节点启动后的累计时间（秒）
        - phase_offset: 当前腿相位偏移（秒）
        - ts: 运动周期（秒）
        - lambda_ratio: 摆动相占比
        - h/xs/xf/zs: 轨迹形状参数
        """
        # 将时间折叠到单个周期内，得到当前周期相位时间 phase_t。
        phase_t = (elapsed + phase_offset) % ts
        # 摆动相持续时间
        swing_t = lambda_ratio * ts

        # 根据当前相位决定是处于摆动相还是支撑相
        if phase_t <= swing_t and swing_t > 1e-6:
            # 摆动相：使用周期性函数平滑过渡（与 MATLAB 中的 sigma 表达式一致）
            # sigma 把摆动相时间映射到 [0, 2pi]
            sigma = (2.0 * math.pi * phase_t) / swing_t

            # x 轨迹采用摆线形式：起终点速度平滑，不会突变
            # x 从 xs 过渡到 xf
            x_orig = (xf - xs) * (sigma - math.sin(sigma)) / (2.0 * math.pi) + xs

            # z 轨迹采用余弦抬升：中段达到最高/最低（取决于 h 符号）
            z_orig = h * (1.0 - math.cos(sigma)) / 2.0 + zs
        else:
            # 支撑相：x 在 xs 和 xf 之间线性插值，z 保持在基准高度 zs
            stance_t = ts - swing_t
            if stance_t <= 1e-6:
                # 极端情况下（几乎无支撑相），退化为固定点，避免除零
                x_orig = xs
                z_orig = zs
            else:
                # tau 是支撑相内的归一化时间 [0,1]
                tau = (phase_t - swing_t) / stance_t
                # 支撑相做线性回程：从 xf 回到 xs
                x_orig = xf + (xs - xf) * tau
                z_orig = zs

        return x_orig, z_orig

    ########################################################################
    # 定时器回调：每次触发都读取参数、计算四条腿位置，并分别发布
    ########################################################################
    def timer_callback(self) -> None:
        """轨迹发布主循环（由定时器驱动）。"""
        t_now = self.get_clock().now()
        # ROS 时间差单位是纳秒，这里转为秒用于轨迹公式
        elapsed = (t_now - self.start_time).nanoseconds * 1e-9

        # 逐周期读取参数，支持运行中动态调参
        ts = float(self.get_parameter('Ts').value)
        lambda_ratio = float(self.get_parameter('lambda_ratio').value)
        h = float(self.get_parameter('h').value)
        xs = float(self.get_parameter('xs').value)
        xf = float(self.get_parameter('xf').value)
        zs = float(self.get_parameter('zs').value)

        # 周期过小时跳过，避免数值异常
        if ts <= 1e-6:
            return

        for leg_name, publisher in self.leg_publishers.items():
            # 每条腿根据自己的相位偏移独立计算
            phase_offset = self.leg_phase_offset_ratio[leg_name] * ts
            x, z = self._compute_foot_position(elapsed, phase_offset, ts, lambda_ratio, h, xs, xf, zs)

            # 发布 Point：本实现中 y 恒为 0（二维矢状面轨迹）
            msg = Point()
            msg.x = float(x)
            msg.y = 0.0
            msg.z = float(z)
            publisher.publish(msg)

            # 终端打印每条腿的足端位置（可选，调试时使用）
            # self.get_logger().debug(f'{leg_name.upper()} - x: {x:.2f}, z: {z:.2f}')


def main(args=None) -> None:
    """ROS2 Python 节点标准入口。"""
    rclpy.init(args=args)
    node = FootTrajectoryPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()