import math
from dataclasses import dataclass
from typing import Dict, Tuple

import rclpy
from geometry_msgs.msg import Point
from geometry_msgs.msg import Vector3
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy
from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy
from std_msgs.msg import UInt8


"""
trot_go_forward.py

整理并封装用于计算四足机器人四个足端位置并发布的节点。

功能：
- 周期性发布四条腿的足端位置（geometry_msgs/Point），用于仿真/控制测试。
- 参数通过 ROS 2 参数服务器配置（周期、摆动比、摆动高度、起止 x、基准 z、话题名、发布频率）。

实现要点：
- 使用 trot 相位（FL/RR 同相，FR/RL 半周期相位差）生成摆动/支撑段轨迹。
- 将参数读取、计算、发布逻辑分离为清晰方法，便于维护和单元测试。

代码主流程：
1) 节点启动后声明并读取参数（话题、发布频率、四腿独立轨迹参数）。
2) 使用统一轨迹生成器，根据每条腿自己的参数计算轨迹。
3) 定时器回调按固定频率执行：
    - 计算当前 elapsed 时间；
    - 读取最新轨迹参数；
    - 对四条腿逐一按腿参数计算足端 (x, z)；
    - 打包成 Point 并发布。

可扩展思路：
- 若要扩展新轨迹曲线，可在 TrajectoryGenerator 中新增计算函数。
- 若要切换步态，可继续保留“每条腿参数独立”的方式，按需扩展参数。
"""


class FootTrajectoryPublisher(Node):
    """足端轨迹发布节点。

    该节点只负责：
    - ROS 参数管理
    - 定时调度与消息发布

    轨迹数学细节由 TrajectoryGenerator 负责，确保后续扩展不破坏主流程。
    """

    def __init__(self) -> None:
        super().__init__('foot_trajectory_publisher')
        self.motion_mode_value = 0
        self.imu_mode_value = 1
        self.current_mode = self.motion_mode_value

        # 你可以把这个节点理解为“总调度器”：
        # 1) 管参数；2) 按固定频率触发；3) 调用轨迹生成器算每条腿位置；4) 发布消息。
        # 轨迹数学细节在生成器类里，主节点尽量保持清晰。

        # 默认参数声明
        # 说明：declare_parameter 只是“注册 + 给默认值”，
        # 真正值可以在 launch/命令行/yaml 里覆盖。
        self.declare_parameter('topic_fl', '/foot_position_fl')
        self.declare_parameter('topic_fr', '/foot_position_fr')
        self.declare_parameter('topic_rl', '/foot_position_rl')
        self.declare_parameter('topic_rr', '/foot_position_rr')
        self.declare_parameter('publish_rate_hz', 50.0)
        self.declare_parameter('joystick_topic', '/joystick_cmd')
        self.declare_parameter('mode_topic', '/motion_mode')
        self.declare_parameter('enable_joystick_control', True)
        self.declare_parameter('turn_gain', 0.6)
        self.declare_parameter('fallback_stride_half_span', 20.0)
        self.declare_parameter('stride_half_span_delta_per_cycle', 8.0)

        # 公共轨迹参数（保留，兼容旧配置）
        # 这些是“默认模板值”，后面会为每条腿生成独立参数。
        self.declare_parameter('Ts', 0.5)
        self.declare_parameter('lambda_ratio', 0.5)
        self.declare_parameter('h', -10.0)
        self.declare_parameter('xs', -20.0)
        self.declare_parameter('xf', 20.0)
        self.declare_parameter('zs', 120.0)

        # 每条腿独立参数（默认继承公共参数值，便于兼容原有配置）
        # 例如 Ts_fl、xs_fr、h_rr 等。
        # 这样做的意义：后续你可以分别给四条腿不同步幅/高度/周期，实现差速转向等功能。
        default_ts = float(self.get_parameter('Ts').value)
        default_lambda_ratio = float(self.get_parameter('lambda_ratio').value)
        default_h = float(self.get_parameter('h').value)
        default_xs = float(self.get_parameter('xs').value)
        default_xf = float(self.get_parameter('xf').value)
        default_zs = float(self.get_parameter('zs').value)
        default_phase_offset_ratio = {
            # 默认 trot 相位关系：FL/RR 同相，FR/RL 半周期差
            'fl': 0.0,
            'rr': 0.0,
            'fr': 0.5,
            'rl': 0.5,
        }
        # 通过循环为四条腿声明独立参数，避免重复代码。
        # self.declare_parameter(f'参数名', default_值) 的方式注册参数，并设置默认值为公共参数的值，确保兼容旧配置。
        for leg_name in ('fl', 'fr', 'rl', 'rr'):
            self.declare_parameter(f'Ts_{leg_name}', default_ts)
            self.declare_parameter(f'lambda_ratio_{leg_name}', default_lambda_ratio)
            self.declare_parameter(f'h_{leg_name}', default_h)
            self.declare_parameter(f'xs_{leg_name}', default_xs)
            self.declare_parameter(f'xf_{leg_name}', default_xf)
            self.declare_parameter(f'zs_{leg_name}', default_zs)
            self.declare_parameter(
                f'phase_offset_ratio_{leg_name}',
                default_phase_offset_ratio[leg_name],
            )

        # 发布器初始化：每条腿对应一个 Point 话题
        # Point 含义：x(前后), y(左右，这里固定0), z(高度)
        """
        declare 只是把参数放进参数服务器，不会自动变成你代码里的普通变量。
        后续 create_publisher(...) 需要一个字符串变量作为话题名，所以要显式读取出来。
        declare = 定义配置项
        get = 取当前配置值并用于业务代码
        如果不 get，就没法把参数值传给发布器、定时器等实际逻辑
        """
        topic_fl = self.get_parameter('topic_fl').value
        topic_fr = self.get_parameter('topic_fr').value
        topic_rl = self.get_parameter('topic_rl').value
        topic_rr = self.get_parameter('topic_rr').value
        rate = float(self.get_parameter('publish_rate_hz').value)

        self.leg_publishers: Dict[str, object] = {
            'fl': self.create_publisher(Point, topic_fl, 10),
            'fr': self.create_publisher(Point, topic_fr, 10),
            'rl': self.create_publisher(Point, topic_rl, 10),
            'rr': self.create_publisher(Point, topic_rr, 10),
        }

        joystick_topic = str(self.get_parameter('joystick_topic').value)
        mode_topic = str(self.get_parameter('mode_topic').value)
        self.enable_joystick_control = bool(self.get_parameter('enable_joystick_control').value)
        self.turn_gain = float(self.get_parameter('turn_gain').value)
        self.fallback_stride_half_span = float(self.get_parameter('fallback_stride_half_span').value)
        self.stride_half_span_delta_per_cycle = float(
            self.get_parameter('stride_half_span_delta_per_cycle').value
        )

        # 左摇杆状态缓存（来自 joystick_command_node 发布的 Vector3）。
        # 这里先给 0，相当于“摇杆居中”，系统上电时不会突然产生大步幅。
        # 约定：
        # - lx 越小（更负）=> 右侧步幅相对更大；
        # - ly<0 前进、ly>0 后退，|ly| 越大步幅越大。
        self.joystick_lx = 0.0
        self.joystick_ly = 0.0
        self.last_update_elapsed_by_leg: Dict[str, float] = {}
        self.limited_half_span_by_leg: Dict[str, float] = {}

        # 订阅手柄话题：
        # - 消息类型 Vector3：x=左摇杆X, y=左摇杆Y, z暂未使用；
        # - 回调只做“数据接收与限幅”，真正映射在 _apply_joystick_adjustment。
        # 这样可以把“通信层”和“控制层”分离，后续更易调试。
        self.joystick_sub = self.create_subscription(
            Vector3,
            joystick_topic,
            self._joystick_callback,
            10,
        )
        # 模式订阅使用 Transient Local，节点后启动时也能立刻收到最近一次模式状态。
        mode_qos = QoSProfile(depth=10)
        mode_qos.reliability = ReliabilityPolicy.RELIABLE
        mode_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
        self.mode_sub = self.create_subscription(
            UInt8,
            mode_topic,
            self._mode_callback,
            mode_qos,
        )

        # 轨迹生成器：统一轨迹算法，不再区分前进/后退/转向“模式”。
        # 运动行为完全由每条腿参数共同决定。
        self.trajectory_generator = TrajectoryGenerator()

        # 时间基准
        # 轨迹是周期函数，需要“当前时刻 - 起始时刻”的 elapsed 来算相位。
        self.start_time = self.get_clock().now()

        # 发布频率保护：若配置非法（<=0），回落到 50Hz（0.02s）
        timer_period = 1.0 / rate if rate > 0.0 else 0.02
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.get_logger().info(
            f'Publishing per-leg trajectory at {rate:.1f} Hz: '
            f'FL={topic_fl}, FR={topic_fr}, RL={topic_rl}, RR={topic_rr}'
        )
        self.get_logger().info(
            f'Mode topic subscribed: {mode_topic}, motion_mode={self.motion_mode_value}, '
            f'imu_mode={self.imu_mode_value}'
        )

    def _mode_callback(self, msg: UInt8) -> None:
        """接收外部模式切换命令。"""
        mode = int(msg.data)
        if mode not in (self.motion_mode_value, self.imu_mode_value):
            self.get_logger().warn(f'Ignore unknown mode value: {mode}')
            return
        if mode == self.current_mode:
            return
        self.current_mode = mode
        mode_name = 'MOTION' if mode == self.motion_mode_value else 'IMU_STABILIZE'
        self.get_logger().info(f'FootTrajectoryPublisher switched to mode: {mode_name} ({mode})')

    def _joystick_callback(self, msg: Vector3) -> None:
        """接收左摇杆输入并做限幅。

        为什么这里要做 max/min：
        - 实际硬件或驱动在边界处可能有轻微越界（例如 1.0001）；
        - 先把输入钳制到 [-1, 1]，可避免后续映射比例异常。
        """
        # x: 左右控制（差速偏置），负值偏向“右腿更大步幅”。
        self.joystick_lx = max(-1.0, min(1.0, float(msg.x)))
        # y: 前后控制（整体步幅与方向）：
        # - y<0 前进，y>0 后退；
        # - |y| 越大，步幅越大。
        self.joystick_ly = max(-1.0, min(1.0, float(msg.y)))

    def _apply_joystick_adjustment(self, leg_name: str, params: 'TrajectoryParams') -> 'TrajectoryParams':
        """将手柄输入映射为步幅与差速转向。

        规则：
        - ly=0 原地；ly<0 前进；ly>0 后退；
        - |ly| 越大，步幅越大；
        - lx 越小（推杆向左）=> 右侧腿步幅相对左侧更大，实现左转趋势。

        设计思路：
        1) 先算“整体步幅比例” stride_scale；
        2) 再算“左右差速因子” side_factor；
        3) 用中心点不变、半步幅缩放的方式重建 xs/xf。
        这样不会改变步幅中心位置，轨迹更平滑、可预期。
        """
        # 允许通过参数一键关闭手柄映射，方便排障或回退到纯参数驱动。
        if not self.enable_joystick_control:
            return params

        # 第一步：由 ly 计算“带方向步幅命令” stride_cmd。
        # stride_cmd 取值 [-1, 1]：
        # - ly=-1 => stride_cmd=+1（前进最大步幅）
        # - ly= 0 => stride_cmd= 0（原地）
        # - ly=+1 => stride_cmd=-1（后退最大步幅）
        stride_cmd = max(-1.0, min(1.0, -self.joystick_ly))

        # 幅值（不含方向）：0 表示原地，1 表示最大步幅。
        stride_scale = abs(stride_cmd)

        # 第二步：由 lx 计算转向偏置。
        # 使用 -lx 的目的是满足你的控制习惯：
        # lx 越小（更负）时，turn_bias 越大（更接近 +1），从而让右侧步幅更大。
        # lx=-1 => turn_bias=+1（明显左转趋势）
        # lx= 0 => turn_bias= 0（直行）
        # lx=+1 => turn_bias=-1（明显右转趋势）
        turn_bias = max(-1.0, min(1.0, -self.joystick_lx))

        # 第三步：将 turn_bias 通过 turn_gain 转成“左右腿差速增益”。
        # turn_gain 越大，同样的摇杆偏转会产生更激进的转向差速。
        side_gain = self.turn_gain * turn_bias
        if leg_name in ('fr', 'rr'):
            # 右侧腿：加增益
            side_factor = 1.0 + side_gain
        else:
            # 左侧腿：减增益
            side_factor = 1.0 - side_gain

        # 安全下限：避免 side_factor 过小导致步幅接近 0 或反向异常。
        side_factor = max(0.1, side_factor)

        # 用中心点 + 半步幅形式重建 xs/xf：
        # center 不变，表示步幅中心位置不漂移；
        # half_span 根据整体比例与左右差速缩放；
        # 再用 stride_cmd 的符号决定前进/后退方向。
        center = (params.xs + params.xf) * 0.5
        half_span = (params.xf - params.xs) * 0.5
        # 若基准步幅为 0（例如 xs=xf=0 用于上电原地），
        # 则采用回退常量作为映射基准，让摇杆拨动后依然可以迈步。
        if abs(half_span) <= 1e-9:
            half_span = abs(self.fallback_stride_half_span)
        direction_sign = 1.0 if stride_cmd >= 0.0 else -1.0
        new_half_span = half_span * stride_scale * side_factor * direction_sign

        return TrajectoryParams(
            ts=params.ts,
            lambda_ratio=params.lambda_ratio,
            h=params.h,
            xs=center - new_half_span,
            xf=center + new_half_span,
            zs=params.zs,
            phase_offset_ratio=params.phase_offset_ratio,
        )

    def _limit_half_span_change_per_cycle(
        self,
        leg_name: str,
        target_half_span: float,
        ts: float,
        elapsed: float,
    ) -> float:
        """限制一个周期内半步幅变化量，避免步长突变。"""
        if ts <= 1e-9:
            return target_half_span

        limit_per_cycle = max(0.0, self.stride_half_span_delta_per_cycle)
        if limit_per_cycle <= 1e-12:
            self.limited_half_span_by_leg[leg_name] = target_half_span
            self.last_update_elapsed_by_leg[leg_name] = elapsed
            return target_half_span

        previous = self.limited_half_span_by_leg.get(leg_name)
        if previous is None:
            self.limited_half_span_by_leg[leg_name] = target_half_span
            self.last_update_elapsed_by_leg[leg_name] = elapsed
            return target_half_span

        last_elapsed = self.last_update_elapsed_by_leg.get(leg_name, elapsed)
        dt = max(0.0, elapsed - last_elapsed)
        max_delta = limit_per_cycle * (dt / ts)

        delta = target_half_span - previous
        if delta > max_delta:
            limited = previous + max_delta
        elif delta < -max_delta:
            limited = previous - max_delta
        else:
            limited = target_half_span

        self.limited_half_span_by_leg[leg_name] = limited
        self.last_update_elapsed_by_leg[leg_name] = elapsed
        return limited

    def _load_trajectory_parameters(self) -> Dict[str, 'TrajectoryParams']:
        """从参数服务器读取每条腿的轨迹参数。

        每个定时器周期都读取一次参数，这样运行中使用 `ros2 param set`
        修改参数后可以立即生效（无需重启节点）。
        """
        leg_params: Dict[str, TrajectoryParams] = {}
        for leg_name in ('fl', 'fr', 'rl', 'rr'):
            # 参数名通过 f-string 动态拼接，例如：xs_fl、xs_fr...
            leg_params[leg_name] = TrajectoryParams(
                ts=float(self.get_parameter(f'Ts_{leg_name}').value),
                lambda_ratio=float(self.get_parameter(f'lambda_ratio_{leg_name}').value),
                h=float(self.get_parameter(f'h_{leg_name}').value),
                xs=float(self.get_parameter(f'xs_{leg_name}').value),
                xf=float(self.get_parameter(f'xf_{leg_name}').value),
                zs=float(self.get_parameter(f'zs_{leg_name}').value),
                phase_offset_ratio=float(self.get_parameter(f'phase_offset_ratio_{leg_name}').value),
            )
        return leg_params

    def _publish_all_feet(self, elapsed: float) -> None:
        """计算并发布四条腿的足端位置。

        执行顺序：
        1) 读取四条腿当前参数；
        2) 对每条腿调用策略计算 (x, z)；
        3) 组装 Point 并发布。
        """
        params_by_leg = self._load_trajectory_parameters()

        for leg_name, publisher in self.leg_publishers.items():
            base_params = params_by_leg[leg_name]
            params = self._apply_joystick_adjustment(leg_name, base_params)
            center = (params.xs + params.xf) * 0.5
            target_half_span = (params.xf - params.xs) * 0.5
            limited_half_span = self._limit_half_span_change_per_cycle(
                leg_name=leg_name,
                target_half_span=target_half_span,
                ts=params.ts,
                elapsed=elapsed,
            )
            params = TrajectoryParams(
                ts=params.ts,
                lambda_ratio=params.lambda_ratio,
                h=params.h,
                xs=center - limited_half_span,
                xf=center + limited_half_span,
                zs=params.zs,
                phase_offset_ratio=params.phase_offset_ratio,
            )
            # ts 为周期，必须为正；过小会导致数值不稳定，跳过当前腿发布。
            if params.ts <= 1e-9:
                continue

            # 将“腿名 + 时间 + 参数”交给轨迹生成器计算，节点不关心内部数学细节。
            x, z = self.trajectory_generator.compute_foot_position(elapsed, params)

            # Point 约定：x 前后方向，y 暂固定为 0，z 高度方向
            msg = Point()
            msg.x = x
            msg.y = 0.0
            msg.z = z
            publisher.publish(msg)

    def timer_callback(self) -> None:
        """定时器回调：作为整个发布流水线的触发器。

        你可以把它看成“心跳函数”：每到一个周期就触发一次完整计算和发布。
        """
        t_now = self.get_clock().now()
        # rclpy 时间差是纳秒，转为秒后用于轨迹相位计算。
        elapsed = (t_now - self.start_time).nanoseconds * 1e-9
        # 只有在“运动模式”才发布步态轨迹；IMU 模式由 imu_stabilizer_node 接管足端输出。
        if self.current_mode != self.motion_mode_value:
            return
        self._publish_all_feet(elapsed)


def main(args=None) -> None:
    """ROS 2 节点标准入口。"""
    rclpy.init(args=args)
    node = FootTrajectoryPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


@dataclass(frozen=True)
class TrajectoryParams:
    """轨迹参数容器。

    字段说明：
    - ts: 步态周期（秒）
    - lambda_ratio: 摆动相比例，范围建议 [0, 1]
    - h: 摆动相抬脚高度（或坐标系定义下的高度偏移）
    - xs/xf: 摆动段起止 x（决定步幅大小与方向）
    - zs: 支撑高度基准
    - phase_offset_ratio: 相位偏移比例（相对于一个周期），可用于腿间相位编排
    """

    ts: float
    lambda_ratio: float
    h: float
    xs: float
    xf: float
    zs: float
    phase_offset_ratio: float


class TrajectoryGenerator:
    """统一轨迹生成器。

    设计目标：
    - 不再区分前进/后退/转向模式；
    - 通过每条腿的独立参数直接定义运动行为；
    - 保持算法集中，便于后续新增其它轨迹曲线。
    """

    def _compute_from_phase(
        self,
        elapsed: float,
        params: TrajectoryParams,
    ) -> Tuple[float, float]:
        """按参数计算单腿轨迹。

        轨迹分为两段：
        - 摆动相：采用余弦/正弦平滑曲线，保证速度连续；
        - 支撑相：x 线性回程，z 保持基准高度。
        """
        phase_offset = params.phase_offset_ratio * params.ts
        # 归一到一个周期内的相位时间 [0, ts)
        phase_t = (elapsed + phase_offset) % params.ts
        # swing_t = 摆动相持续时间 = lambda_ratio * 总周期
        swing_t = params.lambda_ratio * params.ts

        # 摆动段（抬脚段）
        if phase_t <= swing_t and swing_t > 1e-9:
            # sigma 将摆动时间映射到 [0, 2π]
            sigma = (2.0 * math.pi * phase_t) / swing_t
            # x: 类摆线轨迹，起止速度平滑
            x = (params.xf - params.xs) * (sigma - math.sin(sigma)) / (2.0 * math.pi) + params.xs
            # z: 余弦抬升曲线，最高点在中间相位
            z = params.h * (1.0 - math.cos(sigma)) / 2.0 + params.zs
        else:
            # 支撑段（着地推蹬段）
            stance_t = params.ts - swing_t
            if stance_t <= 1e-9:
                # 保护分支：极端参数下退化为固定点
                x = params.xs
                z = params.zs
            else:
                # tau 是支撑段归一化进度 [0, 1]
                tau = (phase_t - swing_t) / stance_t
                # 支撑段线性回程
                x = params.xf + (params.xs - params.xf) * tau
                z = params.zs

        return float(x), float(z)

    def compute_foot_position(self, elapsed: float, params: TrajectoryParams) -> Tuple[float, float]:
        """外部调用入口：根据参数返回当前时刻足端 (x, z)。"""
        return self._compute_from_phase(elapsed, params)


if __name__ == '__main__':
    main()
