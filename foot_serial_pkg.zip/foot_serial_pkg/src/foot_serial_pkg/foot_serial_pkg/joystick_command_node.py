import os
import time
from typing import Optional

import pygame
import rclpy
from geometry_msgs.msg import Vector3
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy
from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy
from std_msgs.msg import UInt8


class JoystickCommandNode(Node):
    """读取手柄左摇杆并发布控制指令。

    约定：
    - msg.x: 左摇杆 X（左右），范围约 [-1, 1]
    - msg.y: 左摇杆 Y（上下），范围约 [-1, 1]
    - msg.z: 预留字段（当前固定 0）
    """

    def __init__(self) -> None:
        super().__init__('joystick_command_node')

        # 模式定义：
        # 0 = 运动模式（按 GREEN 进入，系统按摇杆输出步态轨迹）
        # 1 = IMU 自稳模式（按 BLUE 进入，系统按姿态闭环调腿长）
        self.motion_mode_value = 0
        self.imu_mode_value = 1

        self.declare_parameter('joystick_topic', '/joystick_cmd')
        self.declare_parameter('mode_topic', '/motion_mode')
        self.declare_parameter('publish_rate_hz', 50.0)
        self.declare_parameter('axis_left_x', 0)
        self.declare_parameter('axis_left_y', 1)
        self.declare_parameter('deadzone', 0.05)
        # 设备列表重刷周期（秒）：用于开机自启时手柄晚就绪的场景。
        self.declare_parameter('device_refresh_interval_sec', 1.0)
        # PS2 常见映射：GREEN(三角)=4，BLUE(叉)=0
        self.declare_parameter('button_green', 4)
        self.declare_parameter('button_blue', 0)

        joystick_topic = str(self.get_parameter('joystick_topic').value)
        mode_topic = str(self.get_parameter('mode_topic').value)
        rate = float(self.get_parameter('publish_rate_hz').value)

        self.axis_left_x = int(self.get_parameter('axis_left_x').value)
        self.axis_left_y = int(self.get_parameter('axis_left_y').value)
        self.deadzone = float(self.get_parameter('deadzone').value)
        self.device_refresh_interval_sec = max(
            0.1, float(self.get_parameter('device_refresh_interval_sec').value)
        )
        self.button_green = int(self.get_parameter('button_green').value)
        self.button_blue = int(self.get_parameter('button_blue').value)

        self.publisher = self.create_publisher(Vector3, joystick_topic, 10)
        # 模式话题使用 Transient Local，使新加入的订阅者也能立刻拿到最近一次模式值。
        mode_qos = QoSProfile(depth=10)
        mode_qos.reliability = ReliabilityPolicy.RELIABLE
        mode_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
        self.mode_publisher = self.create_publisher(UInt8, mode_topic, mode_qos)

        self._connected = False
        self._joystick: Optional[pygame.joystick.Joystick] = None
        self._last_green_pressed = False
        self._last_blue_pressed = False
        self._last_device_refresh_time = 0.0
        # 默认上电进入运动模式，并立即发布一次。
        self.current_mode = self.motion_mode_value

        os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
        pygame.display.init()
        pygame.joystick.init()

        timer_period = 1.0 / rate if rate > 0.0 else 0.02
        self.timer = self.create_timer(timer_period, self._timer_callback)

        self.get_logger().info(
            f'Joystick command node started. cmd_topic={joystick_topic}, mode_topic={mode_topic}, '
            f'rate={rate:.1f}Hz'
        )
        self._publish_mode(self.current_mode, reason='startup default')

    def _publish_mode(self, mode_value: int, reason: str) -> None:
        """发布当前模式并记录日志。"""
        msg = UInt8()
        msg.data = int(mode_value) & 0xFF
        self.mode_publisher.publish(msg)
        mode_name = 'MOTION' if mode_value == self.motion_mode_value else 'IMU_STABILIZE'
        self.get_logger().info(f'Mode -> {mode_name} ({msg.data}), reason={reason}')

    def _try_get_button(self, button_index: int) -> bool:
        """安全读取按键状态，避免索引越界导致节点断流。"""
        if self._joystick is None:
            return False
        try:
            button_count = int(self._joystick.get_numbuttons())
        except Exception:
            return False
        if button_index < 0 or button_index >= button_count:
            return False
        try:
            return bool(self._joystick.get_button(button_index))
        except Exception:
            return False

    def _update_mode_from_buttons(self) -> None:
        """通过边沿检测处理 GREEN/BLUE 切换，避免长按时重复触发。"""
        green_pressed = self._try_get_button(self.button_green)
        blue_pressed = self._try_get_button(self.button_blue)

        # GREEN 上升沿：切到运动模式
        if green_pressed and (not self._last_green_pressed):
            if self.current_mode != self.motion_mode_value:
                self.current_mode = self.motion_mode_value
                self._publish_mode(self.current_mode, reason='GREEN pressed')

        # BLUE 上升沿：切到 IMU 自稳模式
        if blue_pressed and (not self._last_blue_pressed):
            if self.current_mode != self.imu_mode_value:
                self.current_mode = self.imu_mode_value
                self._publish_mode(self.current_mode, reason='BLUE pressed')

        self._last_green_pressed = green_pressed
        self._last_blue_pressed = blue_pressed

    def _connect_if_needed(self) -> None:
        if self._connected:
            return

        if not os.path.exists('/dev/input/js0'):
            return

        # 周期性重刷 pygame 手柄设备列表。
        # 原因：systemd 开机自启时，节点可能先于手柄设备就绪。
        # 只靠一次 init 可能长期 get_count()==0，因此这里定时重建设备枚举。
        now = time.monotonic()
        if (now - self._last_device_refresh_time) >= self.device_refresh_interval_sec:
            try:
                pygame.joystick.quit()
            except Exception:
                pass
            try:
                pygame.joystick.init()
            except Exception:
                pass
            self._last_device_refresh_time = now

        if pygame.joystick.get_count() <= 0:
            return

        try:
            self._joystick = pygame.joystick.Joystick(0)
            self._joystick.init()
            self._connected = True
            self.get_logger().info(f'Joystick connected: {self._joystick.get_name()}')
        except Exception as exc:
            self._joystick = None
            self._connected = False
            self.get_logger().warn(f'Joystick connect failed: {exc}')

    def _disconnect(self) -> None:
        if self._joystick is not None:
            try:
                self._joystick.quit()
            except Exception:
                pass
        self._joystick = None
        if self._connected:
            self.get_logger().warn('Joystick disconnected')
        self._connected = False
        self._last_green_pressed = False
        self._last_blue_pressed = False

    def _apply_deadzone(self, value: float) -> float:
        return 0.0 if abs(value) < self.deadzone else value

    def _timer_callback(self) -> None:
        self._connect_if_needed()
        if not self._connected or self._joystick is None:
            return

        if not os.path.exists('/dev/input/js0'):
            self._disconnect()
            return

        try:
            pygame.event.pump()
            # 每次更新事件后先处理模式按键，再处理摇杆数据。
            self._update_mode_from_buttons()
            raw_lx = float(self._joystick.get_axis(self.axis_left_x))
            raw_ly = float(self._joystick.get_axis(self.axis_left_y))
            lx = self._apply_deadzone(raw_lx)
            ly = self._apply_deadzone(raw_ly)

            msg = Vector3()
            msg.x = lx
            msg.y = ly
            msg.z = 0.0
            self.publisher.publish(msg)
        except Exception as exc:
            self.get_logger().warn(f'Joystick read failed: {exc}')
            self._disconnect()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = JoystickCommandNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()