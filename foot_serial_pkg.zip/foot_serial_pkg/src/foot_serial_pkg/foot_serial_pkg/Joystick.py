#!/usr/bin/python3
# coding=utf8
import os
import time
import pygame

#映射PS2手柄按键值
key_map = {"PSB_CROSS":0, "PSB_CIRCLE":1, "PSB_SQUARE":3, "PSB_TRIANGLE":4,
        "PSB_L1": 6, "PSB_R1":7, "PSB_L2":8, "PSB_R2":9,
        "PSB_SELECT":10, "PSB_START":11, "PSB_L3":13, "PSB_R3":14}

#初始化手柄并检测手柄硬件
def joystick_init():
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    pygame.display.init()
    pygame.joystick.init()
    if pygame.joystick.get_count() > 0:
        js=pygame.joystick.Joystick(0)
        js.init()
        jsName = js.get_name()
        print("Name of the joystick:", jsName)
        jsAxes=js.get_numaxes()
        print("Number of axif:",jsAxes)
        jsButtons=js.get_numbuttons()
        print("Number of buttons:", jsButtons)
        jsBall=js.get_numballs()
        print("Numbe of balls:", jsBall)
        jsHat= js.get_numhats()
        print("Number of hats:", jsHat)
        print('Mode:0')

def map_value(x):
    return int((x + 1) * 127.5)

shield = True   #用于模拟模式、数字模式之间的切换
connected = False   #手柄连接状态
last_Lxy = [0,0]  #左摇杆值
last_Rxy = [0,0]  #右摇杆值
key_start = True  #按键状态
while True:
    #检测手柄接收器，并初始化手柄事件
    if os.path.exists("/dev/input/js0") is True:
        if connected is False:
            joystick_init()
            jscount =  pygame.joystick.get_count()
            if jscount > 0:
                try:
                    js=pygame.joystick.Joystick(0)
                    js.init()
                    connected = True
                except Exception as e:
                    print(e)
            else:
                pygame.joystick.quit()
    else:
        if connected is True:
            connected = False
            js.quit()
            pygame.joystick.quit()
    if connected is True:
        pygame.event.pump() #更新手柄数据
        
        try:
            #左摇杆，数字模式下无效
            if js.get_axis(0) != last_Lxy[0] or js.get_axis(1) != last_Lxy[1]:
                if shield:
                    last_Lxy = js.get_axis(0),js.get_axis(1)
                    print("L:[{0},{1}]".format(map_value(last_Lxy[0]),map_value(last_Lxy[1])))
            #右摇杆，数字模式下无效
            if js.get_axis(2) != last_Rxy[0] or js.get_axis(3) != last_Rxy[1]:
                if shield:
                    last_Rxy = js.get_axis(2),js.get_axis(3)
                    print("R:[{0},{1}]".format(map_value(last_Rxy[0]),map_value(last_Rxy[1])))
            #R1按键
            if js.get_button(key_map["PSB_R1"]):
                if shield:  #模拟模式
                    print("R1")
                else:   #数字模式
                    print("R1")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_R1"]):
                        key_start = False
                    key_start = True
            #R2按键
            if js.get_button(key_map["PSB_R2"]):
                if shield:
                    print("R2")
                else:
                    print("R2")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_R2"]):
                        key_start = False
                    key_start = True  
            #L1按键        
            if js.get_button(key_map["PSB_L1"]):
                if shield:
                    print("L1")
                else:
                    print("L1")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_L1"]):
                        key_start = False
                    key_start = True
            #L2按键    
            if js.get_button(key_map["PSB_L2"]):
                if shield:
                    print("L2")
                else:
                    print("L2")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_L2"]):
                        key_start = False
                    key_start = True
            #PINK按键     
            if js.get_button(key_map["PSB_SQUARE"]): #正方形
                if shield:
                    print("PINK")
                else:
                    print("PINK")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_SQUARE"]):
                        key_start = False
                    key_start = True
            #RED按键    
            if js.get_button(key_map["PSB_CIRCLE"]): #圈
                if shield:
                    print("RED")
                else:
                    print("RED")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_CIRCLE"]):
                        key_start = False
                    key_start = True
            #GREEN按键        
            if js.get_button(key_map["PSB_TRIANGLE"]): #三角
                if shield:
                    print("GREEN")
                else:
                    print("GREEN")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_TRIANGLE"]):
                        key_start = False
                    key_start = True
            #BLUE按键        
            if js.get_button(key_map["PSB_CROSS"]): #叉
                if shield:
                    print("BLUE")
                else:
                    print("BLUE")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_CROSS"]):
                        key_start = False
                    key_start = True
            #UP按键        
            if  js.get_hat(0)[0] == 0  and  js.get_hat(0)[1] == 1:
                if shield:
                    print('UP')
                else:
                    print("UP")
                    while key_start:
                      pygame.event.pump()
                      if not(js.get_hat(0)[0] == 0  and  js.get_hat(0)[1] == 1):
                        key_start = False
                    key_start = True
            #DOWN按键        
            elif js.get_hat(0)[0] == 0  and  js.get_hat(0)[1] == -1:
                if shield:
                    print("DOWN")
                else:
                    print("DOWN")
                    while key_start:
                      pygame.event.pump()
                      if not(js.get_hat(0)[0] == 0  and  js.get_hat(0)[1] == -1):
                        key_start = False
                    key_start = True
            #LEFT按键
            elif js.get_hat(0)[0] == -1  and  js.get_hat(0)[1] == 0:
                if shield:
                    print("LEFT")
                else:
                    print("LEFT")
                    while key_start:
                      pygame.event.pump()
                      if not(js.get_hat(0)[0] == -1  and  js.get_hat(0)[1] == 0):
                        key_start = False
                    key_start = True
            #RIGHT按键    
            elif js.get_hat(0)[0] == 1  and  js.get_hat(0)[1] == 0:
                if shield:
                    print("RIGHT") 
                else:
                    print("RIGHT")
                    while key_start:
                      pygame.event.pump()
                      if not(js.get_hat(0)[0] == 1  and  js.get_hat(0)[1] == 0):
                        key_start = False
                    key_start = True
            #START按键      
            if js.get_button(key_map["PSB_START"]):
                if shield:
                    print('START')
                else:
                    print("START")
                    while key_start:
                      pygame.event.pump()
                      if not js.get_button(key_map["PSB_START"]):
                        key_start = False
                    key_start = True
            #模式切换
            if js.get_button(key_map["PSB_SELECT"]):
                time.sleep(0.01)
                if js.get_button(key_map["PSB_START"]):
                    if shield:
                      shield = False
                      print('Mode:1')
                      time.sleep(1)
                    else:
                      shield = True
                      print('Mode:0')
                      time.sleep(1)
        except Exception as e:
            print(e)
            connected = False          
    time.sleep(0.01)
