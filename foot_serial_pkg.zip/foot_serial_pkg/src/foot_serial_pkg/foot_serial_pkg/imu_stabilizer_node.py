from dataclasses import dataclass
from typing import Dict, Optional

import rclpy
from foot_serial_msgs.msg import RobotAttitude
from geometry_msgs.msg import Point
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy
from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy
from std_msgs.msg import UInt8


@dataclass
class PidState:
    """PID 状态容器，用于保存积分项和上一次误差。"""

    integral: float = 0.0
    prev_error: float = 0.0
    derivative_filtered: float = 0.0


class ImuStabilizerNode(Node):
    """IMU 自稳节点。

    功能说明：
    1) 订阅姿态话题（RobotAttitude: roll/pitch/yaw）。
    2) 订阅模式话题（UInt8）：0=运动模式，1=IMU 自稳模式。
    3) 在 IMU 模式下，基于 roll/pitch 与目标姿态（默认 0）的误差，
       通过 PID 计算高度修正量并发布四条腿足端位置。

    控制策略（先实现最稳妥版本）：
    - 保持 x 不变：四条腿在前后方向不踏步，不产生推进。
    - 仅调整 z：通过四腿高度差抵消 roll/pitch 扰动，维持机身水平。
    """

    def __init__(self) -> None:
        super().__init__('imu_stabilizer_node')

        # 模式定义保持与 joystick/trajectory 节点一致。
        self.motion_mode_value = 0
        self.imu_mode_value = 1
        self.current_mode = self.motion_mode_value

        # 话题参数
        self.declare_parameter('attitude_topic', '/attitude')
        self.declare_parameter('mode_topic', '/motion_mode')
        self.declare_parameter('topic_fl', '/foot_position_fl')
        self.declare_parameter('topic_fr', '/foot_position_fr')
        self.declare_parameter('topic_rl', '/foot_position_rl')
        self.declare_parameter('topic_rr', '/foot_position_rr')

        # 控制频率
        self.declare_parameter('publish_rate_hz', 20.0)

        # 站立基准位（IMU 模式下默认足端位置）
        self.declare_parameter('stand_x', 0.0)
        self.declare_parameter('stand_z', 100.0)

        # 姿态目标（水平即 0）
        self.declare_parameter('target_roll', -2.9)
        self.declare_parameter('target_pitch', 1.0)

        # 输出限幅：避免极端姿态或参数异常导致腿长指令过大
        self.declare_parameter('z_min', 80.0)
        self.declare_parameter('z_max', 100.0)
        self.declare_parameter('max_axis_correction', 10.0)

        # Roll/Pitch 两个轴分别配一组 PID 参数，便于独立调参
        self.declare_parameter('roll_kp', 0.05)
        self.declare_parameter('roll_ki', 0.01)
        self.declare_parameter('roll_kd', 0.008)
        self.declare_parameter('pitch_kp', 0.05)
        self.declare_parameter('pitch_ki', 0.01)
        self.declare_parameter('pitch_kd', 0.008)
        self.declare_parameter('integral_limit', 3.0)

        # 防抖增强参数
        # 1) 姿态低通滤波系数 alpha，范围建议 (0, 1]：
        #    y[k] = alpha*x[k] + (1-alpha)*y[k-1]
        #    alpha 越小越平滑，但响应更慢。
        self.declare_parameter('attitude_lpf_alpha', 0.01)
        # 2) 误差死区（单位与姿态一致，通常是度）：
        #    |e| <= deadband 时按 0 处理，抑制“接近水平时来回抖动”。
        self.declare_parameter('roll_error_deadband', 0.3)
        self.declare_parameter('pitch_error_deadband', 0.3)
        # 3) D 项滤波系数：
        #    d_f[k] = alpha_d*d_raw[k] + (1-alpha_d)*d_f[k-1]
        #    用于抑制微分项放大高频噪声。
        self.declare_parameter('derivative_lpf_alpha', 0.2)
        # 4) 控制周期夹紧，避免 dt 异常造成积分或微分尖峰。
        self.declare_parameter('dt_min', 1e-4)
        self.declare_parameter('dt_max', 0.03)

        attitude_topic = str(self.get_parameter('attitude_topic').value)
        mode_topic = str(self.get_parameter('mode_topic').value)
        topic_fl = str(self.get_parameter('topic_fl').value)
        topic_fr = str(self.get_parameter('topic_fr').value)
        topic_rl = str(self.get_parameter('topic_rl').value)
        topic_rr = str(self.get_parameter('topic_rr').value)
        rate_hz = float(self.get_parameter('publish_rate_hz').value)

        self.stand_x = float(self.get_parameter('stand_x').value)
        self.stand_z = float(self.get_parameter('stand_z').value)
        self.target_roll = float(self.get_parameter('target_roll').value)
        self.target_pitch = float(self.get_parameter('target_pitch').value)
        self.z_min = float(self.get_parameter('z_min').value)
        self.z_max = float(self.get_parameter('z_max').value)
        self.max_axis_correction = abs(float(self.get_parameter('max_axis_correction').value))

        self.roll_kp = float(self.get_parameter('roll_kp').value)
        self.roll_ki = float(self.get_parameter('roll_ki').value)
        self.roll_kd = float(self.get_parameter('roll_kd').value)
        self.pitch_kp = float(self.get_parameter('pitch_kp').value)
        self.pitch_ki = float(self.get_parameter('pitch_ki').value)
        self.pitch_kd = float(self.get_parameter('pitch_kd').value)
        self.integral_limit = abs(float(self.get_parameter('integral_limit').value))

        # 读取防抖参数并做安全夹紧。
        self.attitude_lpf_alpha = self._clamp(
            float(self.get_parameter('attitude_lpf_alpha').value),
            1e-4,
            1.0,
        )
        self.roll_error_deadband = abs(float(self.get_parameter('roll_error_deadband').value))
        self.pitch_error_deadband = abs(float(self.get_parameter('pitch_error_deadband').value))
        self.derivative_lpf_alpha = self._clamp(
            float(self.get_parameter('derivative_lpf_alpha').value),
            1e-4,
            1.0,
        )
        self.dt_min = max(1e-6, float(self.get_parameter('dt_min').value))
        self.dt_max = max(self.dt_min, float(self.get_parameter('dt_max').value))

        self.roll_pid = PidState()
        self.pitch_pid = PidState()

        self.last_attitude: Optional[RobotAttitude] = None
        self.last_control_time: Optional[float] = None
        self._warned_no_attitude = False
        # 姿态滤波内部状态：None 表示尚未初始化。
        self.filtered_roll: Optional[float] = None
        self.filtered_pitch: Optional[float] = None

        # 模式话题使用持久化 QoS，确保晚启动节点可读到最新模式。
        mode_qos = QoSProfile(depth=10)
        mode_qos.reliability = ReliabilityPolicy.RELIABLE
        mode_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL

        self.attitude_sub = self.create_subscription(
            RobotAttitude,
            attitude_topic,
            self._attitude_callback,
            10,
        )
        self.mode_sub = self.create_subscription(
            UInt8,
            mode_topic,
            self._mode_callback,
            mode_qos,
        )

        self.leg_publishers: Dict[str, object] = {
            'fl': self.create_publisher(Point, topic_fl, 10),
            'fr': self.create_publisher(Point, topic_fr, 10),
            'rl': self.create_publisher(Point, topic_rl, 10),
            'rr': self.create_publisher(Point, topic_rr, 10),
        }

        timer_period = 1.0 / rate_hz if rate_hz > 0.0 else 0.005
        self.timer = self.create_timer(timer_period, self._timer_callback)

        self.get_logger().info(
            'IMU stabilizer started. '
            f'attitude_topic={attitude_topic}, mode_topic={mode_topic}, rate={rate_hz:.1f}Hz'
        )

    def _attitude_callback(self, msg: RobotAttitude) -> None:
        """缓存最新姿态，供控制回路读取。"""
        self.last_attitude = msg
        self._warned_no_attitude = False

    def _mode_callback(self, msg: UInt8) -> None:
        """更新当前模式，仅识别 0/1。"""
        mode = int(msg.data)
        if mode not in (self.motion_mode_value, self.imu_mode_value):
            self.get_logger().warn(f'Ignore unknown mode value: {mode}')
            return
        if mode == self.current_mode:
            return

        self.current_mode = mode
        # 切换模式时清空 PID 内部状态，避免积分遗留导致跳变。
        self._reset_pid_states()

        mode_name = 'MOTION' if mode == self.motion_mode_value else 'IMU_STABILIZE'
        self.get_logger().info(f'ImuStabilizerNode switched to mode: {mode_name} ({mode})')

    def _reset_pid_states(self) -> None:
        self.roll_pid = PidState()
        self.pitch_pid = PidState()
        self.last_control_time = None
        self.filtered_roll = None
        self.filtered_pitch = None

    def _clamp(self, value: float, vmin: float, vmax: float) -> float:
        return max(vmin, min(vmax, value))

    def _first_order_lpf(self, previous: Optional[float], current: float, alpha: float) -> float:
        """一阶低通滤波。

        数学形式：
            y[k] = alpha * x[k] + (1 - alpha) * y[k-1]

        说明：
        - x[k] 是当前采样（原始姿态或原始微分）
        - y[k] 是滤波后结果
        - alpha 越小，抑制高频越强，但相位滞后更明显
        """
        if previous is None:
            return float(current)
        return float(alpha * current + (1.0 - alpha) * previous)

    def _apply_deadband(self, error: float, deadband: float) -> float:
        """误差死区处理。

        采用“软死区”而不是硬截断：
        - |e| <= d  -> 0
        - e > d     -> e - d
        - e < -d    -> e + d

        好处：
        - 在小误差区间内消除抖动驱动；
        - 越过死区后控制量连续，不会突然跳变。
        """
        if deadband <= 0.0:
            return float(error)
        if abs(error) <= deadband:
            return 0.0
        if error > 0.0:
            return float(error - deadband)
        return float(error + deadband)

    def _pid_step(
        self,
        error: float,
        dt: float,
        state: PidState,
        kp: float,
        ki: float,
        kd: float,
        error_deadband: float,
        derivative_lpf_alpha: float,
    ) -> float:
        """执行一步 PID 计算（含死区、积分限幅、D 项滤波）。"""
        # 死区后的有效误差：在接近水平时，避免控制器追逐噪声。
        error_eff = self._apply_deadband(error, error_deadband)

        # 积分项：仅在 dt 合法时累加，防止时间异常造成积分爆炸。
        if dt > 1e-6:
            state.integral += error_eff * dt
            state.integral = self._clamp(state.integral, -self.integral_limit, self.integral_limit)

        # 原始微分项：对噪声敏感，因此再做一次一阶低通。
        derivative_raw = (error_eff - state.prev_error) / dt if dt > 1e-6 else 0.0
        state.derivative_filtered = self._first_order_lpf(
            previous=state.derivative_filtered,
            current=derivative_raw,
            alpha=derivative_lpf_alpha,
        )
        state.prev_error = error_eff

        # PID 数学形式：u = Kp*e + Ki*∫e dt + Kd*de/dt
        # 这里使用“有效误差 + 滤波微分”以降低抖动。
        output = kp * error_eff + ki * state.integral + kd * state.derivative_filtered
        return float(output)

    def _timer_callback(self) -> None:
        # 只有 IMU 自稳模式才输出足端；运动模式由步态节点接管。
        if self.current_mode != self.imu_mode_value:
            return

        if self.last_attitude is None:
            if not self._warned_no_attitude:
                self.get_logger().warn('No attitude received yet, imu stabilization is waiting...')
                self._warned_no_attitude = True
            return

        now = self.get_clock().now().nanoseconds * 1e-9
        if self.last_control_time is None:
            # 首次执行采用保守 dt，避免微分项因 dt 过小而抖动。
            dt = 0.01
        else:
            dt = now - self.last_control_time
            # 将 dt 限制在合理区间，减少调度抖动对 PID 的影响。
            dt = self._clamp(dt, self.dt_min, self.dt_max)
        self.last_control_time = now

        # 先对原始姿态做一阶低通，抑制 IMU 高频噪声。
        self.filtered_roll = self._first_order_lpf(
            previous=self.filtered_roll,
            current=float(self.last_attitude.roll),
            alpha=self.attitude_lpf_alpha,
        )
        self.filtered_pitch = self._first_order_lpf(
            previous=self.filtered_pitch,
            current=float(self.last_attitude.pitch),
            alpha=self.attitude_lpf_alpha,
        )

        # 目标为水平：误差 = 目标 - 当前。
        err_roll = self.target_roll - (- float(self.filtered_roll))
        err_pitch = self.target_pitch - (- float(self.filtered_pitch))

        # 计算两个轴的控制量，并分别限幅。
        u_roll = self._pid_step(
            error=err_roll,
            dt=dt,
            state=self.roll_pid,
            kp=self.roll_kp,
            ki=self.roll_ki,
            kd=self.roll_kd,
            error_deadband=self.roll_error_deadband,
            derivative_lpf_alpha=self.derivative_lpf_alpha,
        )
        u_pitch = self._pid_step(
            error=err_pitch,
            dt=dt,
            state=self.pitch_pid,
            kp=self.pitch_kp,
            ki=self.pitch_ki,
            kd=self.pitch_kd,
            error_deadband=self.pitch_error_deadband,
            derivative_lpf_alpha=self.derivative_lpf_alpha,
        )
        u_roll = self._clamp(u_roll, -self.max_axis_correction, self.max_axis_correction)
        u_pitch = self._clamp(u_pitch, -self.max_axis_correction, self.max_axis_correction)

        # 将 roll/pitch 控制量分配到四条腿高度。
        # 约定：
        # - pitch 轴：前腿与后腿做反向调整；
        # - roll 轴：左腿与右腿做反向调整。
        dz_by_leg = {
            'fl': u_pitch + u_roll,
            'fr': u_pitch - u_roll,
            'rl': -u_pitch + u_roll,
            'rr': -u_pitch - u_roll,
        }

        for leg_name, publisher in self.leg_publishers.items():
            msg = Point()
            # 保持 x 不变：不踏步，仅做原地姿态调平。
            msg.x = float(self.stand_x)
            msg.y = 0.0
            # 只调整 z：将基准站立高度 + 控制修正后再做安全限幅。
            target_z = self.stand_z + dz_by_leg[leg_name]
            msg.z = float(self._clamp(target_z, self.z_min, self.z_max))
            publisher.publish(msg)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = ImuStabilizerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
