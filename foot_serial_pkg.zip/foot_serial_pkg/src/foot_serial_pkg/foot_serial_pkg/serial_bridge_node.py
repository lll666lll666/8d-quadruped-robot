import struct

import rclpy
import serial
from foot_serial_msgs.msg import RobotAttitude
from geometry_msgs.msg import Point
from rclpy.node import Node

# 模块说明：
# 该节点订阅四条腿足端位置 (`geometry_msgs/Point`)，将 x 与 z 两个 float32 值打包成自定义串口帧，
# 并通过串口转发给下位机。帧格式为：
#   start_byte (1B) | flag_byte (1B) | leg_id (1B) | payload (8B: <float32 x, float32 z 小端) | end_byte (1B)
# 默认起始字节为 0xAA，结束字节为 0x55。
# 同时支持最小姿态帧接收：
#   0xBB | 0xA1 | pitch(float32) | roll(float32) | yaw(float32) | 0x55
# 接收到后发布到姿态话题（RobotAttitude: roll, pitch, yaw）。


class SerialBridgeNode(Node):
    def __init__(self) -> None:
        super().__init__('serial_bridge_node')

        # 声明参数：四条腿话题、串口、波特率、超时以及帧定界字节
        self.declare_parameter('topic_fl', '/foot_position_fl')
        self.declare_parameter('topic_fr', '/foot_position_fr')
        self.declare_parameter('topic_rl', '/foot_position_rl')
        self.declare_parameter('topic_rr', '/foot_position_rr')
        self.declare_parameter('serial_port', '/dev/ttyAMA10')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('timeout', 0.02)
        # start_byte 与 end_byte 用于帧同步，flag_byte 用作自定义消息标识
        # 使用十六进制字面量更直观地表示常见的帧定界符（例如 0xAA, 0x55）
        self.declare_parameter('start_byte', 0xAA)   # 0xAA (170)
        self.declare_parameter('flag_byte', 0x01)    # 0x01 (1)
        self.declare_parameter('end_byte', 0x55)     # 0x55 (85)
        # 下位机姿态帧（接收）配置
        self.declare_parameter('attitude_topic', '/attitude')
        self.declare_parameter('rx_start_byte', 0xBB)
        self.declare_parameter('rx_flag_byte', 0xA1)
        self.declare_parameter('rx_end_byte', 0x55)

        topic_fl = self.get_parameter('topic_fl').value
        topic_fr = self.get_parameter('topic_fr').value
        topic_rl = self.get_parameter('topic_rl').value
        topic_rr = self.get_parameter('topic_rr').value
        port = self.get_parameter('serial_port').value
        baudrate = int(self.get_parameter('baudrate').value)
        timeout = float(self.get_parameter('timeout').value)
        attitude_topic = self.get_parameter('attitude_topic').value
        
        # 发送频率（Hz），默认为 200Hz
        self.declare_parameter('send_rate_hz', 200.0)
        send_rate = float(self.get_parameter('send_rate_hz').value)

        # 保存串口配置信息以便重试打开
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout

        # 确保字节值为 0-255 范围
        self.start_byte = int(self.get_parameter('start_byte').value) & 0xFF
        self.flag_byte = int(self.get_parameter('flag_byte').value) & 0xFF
        self.end_byte = int(self.get_parameter('end_byte').value) & 0xFF
        self.rx_start_byte = int(self.get_parameter('rx_start_byte').value) & 0xFF
        self.rx_flag_byte = int(self.get_parameter('rx_flag_byte').value) & 0xFF
        self.rx_end_byte = int(self.get_parameter('rx_end_byte').value) & 0xFF
        self.rx_frame_len = 15
        self.rx_buffer = bytearray()
        # 每条腿对应一个 ID：用于插入到 flag 后，标识该帧对应哪条腿
        self.leg_id_map = {
            'fl': 0x01,
            'fr': 0x02,
            'rl': 0x03,
            'rr': 0x04,
        }

        self.serial_conn = None
        # 标记是否已记录串口不可用的警告，避免日志刷屏
        self._serial_warned = False
        # 打开串口（若失败会记录错误但不会抛出）
        self._open_serial(port, baudrate, timeout)

        # 订阅四条腿 Point 话题
        self._subscriptions = []
        topic_map = {
            'fl': topic_fl,
            'fr': topic_fr,
            'rl': topic_rl,
            'rr': topic_rr,
        }
        for leg_name, topic_name in topic_map.items():
            sub = self.create_subscription(
                Point,
                topic_name,
                self._make_topic_callback(leg_name),
                10,
            )
            self._subscriptions.append(sub)

        # 存储每条腿最近一次收到的点，由订阅回调更新；定时器按固定频率发送
        self.last_points = {
            'fl': None,
            'fr': None,
            'rl': None,
            'rr': None,
        }
        timer_period = 1.0 / send_rate if send_rate > 0.0 else 0.05
        self.send_timer = self.create_timer(timer_period, self._send_timer_callback)
        self.attitude_pub = self.create_publisher(RobotAttitude, attitude_topic, 10)

        self.get_logger().info(
            f'Subscribed FL/FR/RL/RR, forwarding to {port}@{baudrate} at {send_rate}Hz'
        )
        self.get_logger().info(f'Attitude RX enabled, publishing to {attitude_topic}')

    def _open_serial(self, port: str, baudrate: int, timeout: float) -> None:
        # 尝试打开指定串口，设置为无校验、1 个停止位、8 位数据位
        try:
            self.serial_conn = serial.Serial(
                port=port,
                baudrate=baudrate,
                timeout=timeout,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
            )
            self.get_logger().info(f'Serial opened: {port}')
            # 重置警告标记
            self._serial_warned = False
        except Exception as exc:
            # 打开失败时将 serial_conn 置为 None，日志记录错误原因
            self.serial_conn = None
            self.get_logger().error(f'Failed to open serial {port}: {exc}')

    def _make_topic_callback(self, leg_name: str):
        def _callback(msg: Point) -> None:
            # 仅更新缓存最近收到的点，由定时器以固定频率发送（避免订阅回调频率波动导致串口发送不规律）
            self.last_points[leg_name] = msg
            # 记录接收到的点，帮助排查数据流是否到达该节点
            try:
                self.get_logger().debug(
                    f'Received {leg_name}: x={float(msg.x):.3f} y={float(msg.y):.3f} z={float(msg.z):.3f}'
                )
            except Exception:
                # 保守处理任意 msg 字段异常
                self.get_logger().debug(f'Received {leg_name} point')

        return _callback

    def _build_frame(self, leg_name: str, point: Point) -> bytes:
        # 帧格式：start | flag | leg_id | payload(x,z) | end
        payload = struct.pack('<ff', float(point.x), float(point.z))
        leg_id = self.leg_id_map[leg_name] & 0xFF
        return bytes([self.start_byte, self.flag_byte, leg_id]) + payload + bytes([self.end_byte])

    def _send_timer_callback(self) -> None:
        # 定时器回调：以固定频率发送四条腿最近一次收到的点
        # 如果串口未打开，尝试重连一次；失败则返回
        if self.serial_conn is None or not self.serial_conn.is_open:
            # 尝试重连
            try:
                self._open_serial(self.port, self.baudrate, self.timeout)
            except Exception:
                pass
            if self.serial_conn is None or not self.serial_conn.is_open:
                if not self._serial_warned:
                    self.get_logger().warning('Serial not open; cannot send frames')
                    self._serial_warned = True
                return

        # 遍历四条腿，如果有新点则构建帧并发送；发送成功后在日志中打印发送的内容（包括腿名、x、z）
        for leg_name in ('fl', 'fr', 'rl', 'rr'):
            point = self.last_points[leg_name]
            if point is None:
                continue
            # 构建帧并发送
            frame = self._build_frame(leg_name, point)
            try:
                # 发送帧到串口，捕获并记录任何发送错误
                self.serial_conn.write(frame)
                try:
                    # 尽量 flush 以确保数据尽快发出（若底层驱动支持）
                    self.serial_conn.flush()
                except Exception:
                    # flush 不是必须的，忽略可能的错误
                    pass
            except Exception as exc:
                self.get_logger().error(f'Serial write error ({leg_name}): {exc}')
            else:
                leg_id = self.leg_id_map[leg_name]
                self.get_logger().info(
                    f'Sent frame -> leg={leg_name} id={leg_id} x={float(point.x):.3f} z={float(point.z):.3f}'
                )
                try:
                    hex_str = ' '.join(f'{b:02X}' for b in frame)
                    self.get_logger().debug(f'Frame hex: {hex_str}')
                except Exception:
                    pass

        # 轮询串口接收并解析姿态帧
        self._poll_attitude_receive()

    def _poll_attitude_receive(self) -> None:
        if self.serial_conn is None or not self.serial_conn.is_open:
            return

        try:
            waiting = int(self.serial_conn.in_waiting)
        except Exception:
            waiting = 0

        if waiting > 0:
            try:
                data = self.serial_conn.read(waiting)
            except Exception as exc:
                self.get_logger().error(f'Serial read error: {exc}')
                return
            if data:
                self.rx_buffer.extend(data)

        self._parse_attitude_frames_from_buffer()

    def _parse_attitude_frames_from_buffer(self) -> None:
        while True:
            # 至少需要完整帧长度
            if len(self.rx_buffer) < self.rx_frame_len:
                return

            # 尝试同步到起始字节
            start_idx = self.rx_buffer.find(bytes([self.rx_start_byte]))
            if start_idx < 0:
                self.rx_buffer.clear()
                return
            if start_idx > 0:
                del self.rx_buffer[:start_idx]

            if len(self.rx_buffer) < self.rx_frame_len:
                return

            frame = self.rx_buffer[:self.rx_frame_len]

            # 帧头/帧尾/标志位校验失败时丢弃一个字节并重试
            if frame[1] != self.rx_flag_byte or frame[14] != self.rx_end_byte:
                del self.rx_buffer[0]
                continue

            try:
                pitch, roll, yaw = struct.unpack('<fff', frame[2:14])
            except Exception:
                del self.rx_buffer[0]
                continue

            msg = RobotAttitude()
            msg.roll = float(roll)
            msg.pitch = float(pitch)
            msg.yaw = float(yaw)
            self.attitude_pub.publish(msg)
            self.get_logger().debug(
                f'Recv attitude: roll={msg.roll:.3f} pitch={msg.pitch:.3f} yaw={msg.yaw:.3f}'
            )

            # 移除已消费的完整帧，继续尝试解析后续数据
            del self.rx_buffer[:self.rx_frame_len]

    def destroy_node(self):
        # 关闭串口并销毁节点
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
        super().destroy_node()


def main(args=None) -> None:
    rclpy.init(args=args)
    node = SerialBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
