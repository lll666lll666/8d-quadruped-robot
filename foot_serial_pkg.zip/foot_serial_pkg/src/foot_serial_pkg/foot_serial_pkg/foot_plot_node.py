import threading
import time
from collections import deque

import matplotlib.animation as animation
import matplotlib.pyplot as plt
import rclpy
from geometry_msgs.msg import Point
from rclpy.node import Node


# 模块说明：
# 该节点订阅足端位置（geometry_msgs/Point），并在一个 Matplotlib 窗口中实时绘制 x-z 轨迹。
# 设计：将 ROS 订阅放在 rclpy 的后台线程（spin），主线程运行 Matplotlib 的事件循环。
# 使用锁保护共享数据缓冲区（时间戳、x、z）。
# 运行 python3 -m foot_serial_pkg.foot_plot_node 可查看

class FootPlotNode(Node):
    def __init__(self) -> None:
        super().__init__('foot_plot_node')

        # 参数：订阅话题、绘图频率、可视化时间窗口
        self.declare_parameter('topic_name', '/foot_position')
        self.declare_parameter('plot_rate_hz', 20.0)
        self.declare_parameter('window_seconds', 5.0)

        topic_name = self.get_parameter('topic_name').value
        self.plot_rate_hz = float(self.get_parameter('plot_rate_hz').value)
        self.window_seconds = float(self.get_parameter('window_seconds').value)

        # 使用 deque 保存时间戳与坐标，避免无限增长
        maxlen = int(self.plot_rate_hz * self.window_seconds * 2) or 100
        self.times = deque(maxlen=maxlen)
        self.xs = deque(maxlen=maxlen)
        self.zs = deque(maxlen=maxlen)

        self._lock = threading.Lock()

        # 订阅话题
        self.subscription = self.create_subscription(
            Point,
            topic_name,
            self._point_callback,
            10,
        )

        self.get_logger().info(f'FootPlotNode subscribing to {topic_name}, plotting {self.window_seconds}s at {self.plot_rate_hz}Hz')

    def _point_callback(self, msg: Point) -> None:
        # 回调仅负责缓存数据，绘图在主线程通过定时器拉取
        with self._lock:
            self.times.append(time.time())
            self.xs.append(float(msg.x))
            self.zs.append(float(msg.z))

    def get_data_copy(self):
        # 返回当前缓存的时间、x、z 副本（线程安全）
        with self._lock:
            return list(self.times), list(self.xs), list(self.zs)


def main(args=None):
    # 初始化 rclpy 与节点
    rclpy.init(args=args)
    node = FootPlotNode()

    # 在后台线程运行 ROS spin
    ros_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    ros_thread.start()

    # Matplotlib 绘图初始化（在主线程）
    fig, ax = plt.subplots()
    line, = ax.plot([], [], '-o', markersize=4)
    ax.set_xlabel('x')
    ax.set_ylabel('z')
    ax.set_title('Foot position (x vs z)')
    ax.grid(True)

    # 更新函数（由 FuncAnimation 周期性调用）
    def update(frame):
        times, xs, zs = node.get_data_copy()
        if not xs:
            return line,

        # 只显示最近 window_seconds 的数据
        t_now = time.time()
        cutoff = t_now - node.window_seconds
        # 找第一个满足 cutoff 的索引
        start_idx = 0
        for i, t in enumerate(times):
            if t >= cutoff:
                start_idx = i
                break

        xs_window = xs[start_idx:]
        zs_window = zs[start_idx:]

        line.set_data(xs_window, zs_window)
        # 自适应坐标范围（保留少量边距）
        if xs_window and zs_window:
            margin_x = (max(xs_window) - min(xs_window)) * 0.1 if len(xs_window) > 1 else 1.0
            margin_z = (max(zs_window) - min(zs_window)) * 0.1 if len(zs_window) > 1 else 1.0
            ax.set_xlim(min(xs_window) - margin_x, max(xs_window) + margin_x)
            ax.set_ylim(min(zs_window) - margin_z, max(zs_window) + margin_z)

        return line,

    interval_ms = int(1000.0 / node.plot_rate_hz)
    ani = animation.FuncAnimation(fig, update, interval=interval_ms, blit=True)

    try:
        plt.show()
    except Exception:
        pass
    finally:
        # 关闭时清理 ROS
        node.get_logger().info('Closing plot, shutting down node...')
        node.destroy_node()
        rclpy.shutdown()
        ros_thread.join(timeout=1.0)


if __name__ == '__main__':
    main()
