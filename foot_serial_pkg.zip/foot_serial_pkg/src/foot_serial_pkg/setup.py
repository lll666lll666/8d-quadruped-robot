from setuptools import find_packages, setup

package_name = 'foot_serial_pkg'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/foot_serial.launch.py']),
    ],
    install_requires=['setuptools', 'pyserial', 'pygame'],
    zip_safe=True,
    maintainer='jiang',
    maintainer_email='user@example.com',
    description='ROS2 nodes for foot trajectory publishing and serial communication',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'trot_go_forward = foot_serial_pkg.trot_go_forward:main',
            'foot_trajectory_publisher = foot_serial_pkg.foot_trajectory_publisher:main',
            'joystick_command_node = foot_serial_pkg.joystick_command_node:main',
            'serial_bridge_node = foot_serial_pkg.serial_bridge_node:main',
            'imu_stabilizer_node = foot_serial_pkg.imu_stabilizer_node:main',
        ],
    },
)
