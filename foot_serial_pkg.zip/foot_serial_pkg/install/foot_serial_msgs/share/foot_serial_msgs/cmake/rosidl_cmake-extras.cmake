# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(foot_serial_msgs_IDL_FILES "msg/RobotAttitude.idl")
set(foot_serial_msgs_INTERFACE_FILES "msg/RobotAttitude.msg")
