// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "foot_serial_msgs/msg/detail/robot_attitude__functions.h"
#include "foot_serial_msgs/msg/detail/robot_attitude__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace foot_serial_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void RobotAttitude_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) foot_serial_msgs::msg::RobotAttitude(_init);
}

void RobotAttitude_fini_function(void * message_memory)
{
  auto typed_message = static_cast<foot_serial_msgs::msg::RobotAttitude *>(message_memory);
  typed_message->~RobotAttitude();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember RobotAttitude_message_member_array[3] = {
  {
    "roll",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foot_serial_msgs::msg::RobotAttitude, roll),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "pitch",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foot_serial_msgs::msg::RobotAttitude, pitch),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "yaw",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foot_serial_msgs::msg::RobotAttitude, yaw),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers RobotAttitude_message_members = {
  "foot_serial_msgs::msg",  // message namespace
  "RobotAttitude",  // message name
  3,  // number of fields
  sizeof(foot_serial_msgs::msg::RobotAttitude),
  false,  // has_any_key_member_
  RobotAttitude_message_member_array,  // message members
  RobotAttitude_init_function,  // function to initialize message memory (memory has to be allocated)
  RobotAttitude_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t RobotAttitude_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &RobotAttitude_message_members,
  get_message_typesupport_handle_function,
  &foot_serial_msgs__msg__RobotAttitude__get_type_hash,
  &foot_serial_msgs__msg__RobotAttitude__get_type_description,
  &foot_serial_msgs__msg__RobotAttitude__get_type_description_sources,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace foot_serial_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<foot_serial_msgs::msg::RobotAttitude>()
{
  return &::foot_serial_msgs::msg::rosidl_typesupport_introspection_cpp::RobotAttitude_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, foot_serial_msgs, msg, RobotAttitude)() {
  return &::foot_serial_msgs::msg::rosidl_typesupport_introspection_cpp::RobotAttitude_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
