// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice
#include "foot_serial_msgs/msg/detail/robot_attitude__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
foot_serial_msgs__msg__RobotAttitude__init(foot_serial_msgs__msg__RobotAttitude * msg)
{
  if (!msg) {
    return false;
  }
  // roll
  // pitch
  // yaw
  return true;
}

void
foot_serial_msgs__msg__RobotAttitude__fini(foot_serial_msgs__msg__RobotAttitude * msg)
{
  if (!msg) {
    return;
  }
  // roll
  // pitch
  // yaw
}

bool
foot_serial_msgs__msg__RobotAttitude__are_equal(const foot_serial_msgs__msg__RobotAttitude * lhs, const foot_serial_msgs__msg__RobotAttitude * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // roll
  if (lhs->roll != rhs->roll) {
    return false;
  }
  // pitch
  if (lhs->pitch != rhs->pitch) {
    return false;
  }
  // yaw
  if (lhs->yaw != rhs->yaw) {
    return false;
  }
  return true;
}

bool
foot_serial_msgs__msg__RobotAttitude__copy(
  const foot_serial_msgs__msg__RobotAttitude * input,
  foot_serial_msgs__msg__RobotAttitude * output)
{
  if (!input || !output) {
    return false;
  }
  // roll
  output->roll = input->roll;
  // pitch
  output->pitch = input->pitch;
  // yaw
  output->yaw = input->yaw;
  return true;
}

foot_serial_msgs__msg__RobotAttitude *
foot_serial_msgs__msg__RobotAttitude__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  foot_serial_msgs__msg__RobotAttitude * msg = (foot_serial_msgs__msg__RobotAttitude *)allocator.allocate(sizeof(foot_serial_msgs__msg__RobotAttitude), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(foot_serial_msgs__msg__RobotAttitude));
  bool success = foot_serial_msgs__msg__RobotAttitude__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
foot_serial_msgs__msg__RobotAttitude__destroy(foot_serial_msgs__msg__RobotAttitude * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    foot_serial_msgs__msg__RobotAttitude__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
foot_serial_msgs__msg__RobotAttitude__Sequence__init(foot_serial_msgs__msg__RobotAttitude__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  foot_serial_msgs__msg__RobotAttitude * data = NULL;

  if (size) {
    data = (foot_serial_msgs__msg__RobotAttitude *)allocator.zero_allocate(size, sizeof(foot_serial_msgs__msg__RobotAttitude), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = foot_serial_msgs__msg__RobotAttitude__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        foot_serial_msgs__msg__RobotAttitude__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
foot_serial_msgs__msg__RobotAttitude__Sequence__fini(foot_serial_msgs__msg__RobotAttitude__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      foot_serial_msgs__msg__RobotAttitude__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

foot_serial_msgs__msg__RobotAttitude__Sequence *
foot_serial_msgs__msg__RobotAttitude__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  foot_serial_msgs__msg__RobotAttitude__Sequence * array = (foot_serial_msgs__msg__RobotAttitude__Sequence *)allocator.allocate(sizeof(foot_serial_msgs__msg__RobotAttitude__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = foot_serial_msgs__msg__RobotAttitude__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
foot_serial_msgs__msg__RobotAttitude__Sequence__destroy(foot_serial_msgs__msg__RobotAttitude__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    foot_serial_msgs__msg__RobotAttitude__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
foot_serial_msgs__msg__RobotAttitude__Sequence__are_equal(const foot_serial_msgs__msg__RobotAttitude__Sequence * lhs, const foot_serial_msgs__msg__RobotAttitude__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!foot_serial_msgs__msg__RobotAttitude__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
foot_serial_msgs__msg__RobotAttitude__Sequence__copy(
  const foot_serial_msgs__msg__RobotAttitude__Sequence * input,
  foot_serial_msgs__msg__RobotAttitude__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(foot_serial_msgs__msg__RobotAttitude);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    foot_serial_msgs__msg__RobotAttitude * data =
      (foot_serial_msgs__msg__RobotAttitude *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!foot_serial_msgs__msg__RobotAttitude__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          foot_serial_msgs__msg__RobotAttitude__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!foot_serial_msgs__msg__RobotAttitude__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
