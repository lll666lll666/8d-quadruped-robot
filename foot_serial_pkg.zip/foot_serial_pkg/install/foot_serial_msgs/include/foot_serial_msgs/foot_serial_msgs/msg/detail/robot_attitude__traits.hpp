// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "foot_serial_msgs/msg/robot_attitude.hpp"


#ifndef FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TRAITS_HPP_
#define FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "foot_serial_msgs/msg/detail/robot_attitude__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace foot_serial_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RobotAttitude & msg,
  std::ostream & out)
{
  out << "{";
  // member: roll
  {
    out << "roll: ";
    rosidl_generator_traits::value_to_yaml(msg.roll, out);
    out << ", ";
  }

  // member: pitch
  {
    out << "pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.pitch, out);
    out << ", ";
  }

  // member: yaw
  {
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RobotAttitude & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "roll: ";
    rosidl_generator_traits::value_to_yaml(msg.roll, out);
    out << "\n";
  }

  // member: pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.pitch, out);
    out << "\n";
  }

  // member: yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RobotAttitude & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace foot_serial_msgs

namespace rosidl_generator_traits
{

[[deprecated("use foot_serial_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const foot_serial_msgs::msg::RobotAttitude & msg,
  std::ostream & out, size_t indentation = 0)
{
  foot_serial_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use foot_serial_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const foot_serial_msgs::msg::RobotAttitude & msg)
{
  return foot_serial_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<foot_serial_msgs::msg::RobotAttitude>()
{
  return "foot_serial_msgs::msg::RobotAttitude";
}

template<>
inline const char * name<foot_serial_msgs::msg::RobotAttitude>()
{
  return "foot_serial_msgs/msg/RobotAttitude";
}

template<>
struct has_fixed_size<foot_serial_msgs::msg::RobotAttitude>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<foot_serial_msgs::msg::RobotAttitude>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<foot_serial_msgs::msg::RobotAttitude>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TRAITS_HPP_
