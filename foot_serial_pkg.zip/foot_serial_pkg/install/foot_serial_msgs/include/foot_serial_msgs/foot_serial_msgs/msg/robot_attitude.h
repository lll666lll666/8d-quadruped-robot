// generated from rosidl_generator_c/resource/idl.h.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

#ifndef FOOT_SERIAL_MSGS__MSG__ROBOT_ATTITUDE_H_
#define FOOT_SERIAL_MSGS__MSG__ROBOT_ATTITUDE_H_

#include "foot_serial_msgs/msg/detail/robot_attitude__struct.h"
#include "foot_serial_msgs/msg/detail/robot_attitude__functions.h"
#include "foot_serial_msgs/msg/detail/robot_attitude__type_support.h"

#endif  // FOOT_SERIAL_MSGS__MSG__ROBOT_ATTITUDE_H_
