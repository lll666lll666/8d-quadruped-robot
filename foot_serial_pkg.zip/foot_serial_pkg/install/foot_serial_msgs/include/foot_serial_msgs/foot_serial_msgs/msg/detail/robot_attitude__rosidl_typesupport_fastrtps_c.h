// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice
#ifndef FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "foot_serial_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "foot_serial_msgs/msg/detail/robot_attitude__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
bool cdr_serialize_foot_serial_msgs__msg__RobotAttitude(
  const foot_serial_msgs__msg__RobotAttitude * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
bool cdr_deserialize_foot_serial_msgs__msg__RobotAttitude(
  eprosima::fastcdr::Cdr &,
  foot_serial_msgs__msg__RobotAttitude * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
size_t get_serialized_size_foot_serial_msgs__msg__RobotAttitude(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
size_t max_serialized_size_foot_serial_msgs__msg__RobotAttitude(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
bool cdr_serialize_key_foot_serial_msgs__msg__RobotAttitude(
  const foot_serial_msgs__msg__RobotAttitude * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
size_t get_serialized_size_key_foot_serial_msgs__msg__RobotAttitude(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
size_t max_serialized_size_key_foot_serial_msgs__msg__RobotAttitude(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_foot_serial_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, foot_serial_msgs, msg, RobotAttitude)();

#ifdef __cplusplus
}
#endif

#endif  // FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
