// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "foot_serial_msgs/msg/robot_attitude.h"


#ifndef FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__STRUCT_H_
#define FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/RobotAttitude in the package foot_serial_msgs.
typedef struct foot_serial_msgs__msg__RobotAttitude
{
  float roll;
  float pitch;
  float yaw;
} foot_serial_msgs__msg__RobotAttitude;

// Struct for a sequence of foot_serial_msgs__msg__RobotAttitude.
typedef struct foot_serial_msgs__msg__RobotAttitude__Sequence
{
  foot_serial_msgs__msg__RobotAttitude * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foot_serial_msgs__msg__RobotAttitude__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__STRUCT_H_
