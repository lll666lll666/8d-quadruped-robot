// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

#include "foot_serial_msgs/msg/detail/robot_attitude__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_foot_serial_msgs
const rosidl_type_hash_t *
foot_serial_msgs__msg__RobotAttitude__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x5e, 0x3f, 0xfb, 0x94, 0x40, 0xdc, 0x45, 0x2b,
      0x4a, 0xd1, 0xfd, 0x14, 0x65, 0x45, 0x70, 0xf9,
      0xef, 0xe5, 0x0d, 0x44, 0x15, 0xbd, 0x4c, 0xb5,
      0x5c, 0x9b, 0xb3, 0x82, 0x6d, 0x88, 0xfd, 0xd2,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char foot_serial_msgs__msg__RobotAttitude__TYPE_NAME[] = "foot_serial_msgs/msg/RobotAttitude";

// Define type names, field names, and default values
static char foot_serial_msgs__msg__RobotAttitude__FIELD_NAME__roll[] = "roll";
static char foot_serial_msgs__msg__RobotAttitude__FIELD_NAME__pitch[] = "pitch";
static char foot_serial_msgs__msg__RobotAttitude__FIELD_NAME__yaw[] = "yaw";

static rosidl_runtime_c__type_description__Field foot_serial_msgs__msg__RobotAttitude__FIELDS[] = {
  {
    {foot_serial_msgs__msg__RobotAttitude__FIELD_NAME__roll, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {foot_serial_msgs__msg__RobotAttitude__FIELD_NAME__pitch, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {foot_serial_msgs__msg__RobotAttitude__FIELD_NAME__yaw, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
foot_serial_msgs__msg__RobotAttitude__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {foot_serial_msgs__msg__RobotAttitude__TYPE_NAME, 34, 34},
      {foot_serial_msgs__msg__RobotAttitude__FIELDS, 3, 3},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "float32 roll\n"
  "float32 pitch\n"
  "float32 yaw";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
foot_serial_msgs__msg__RobotAttitude__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {foot_serial_msgs__msg__RobotAttitude__TYPE_NAME, 34, 34},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 39, 39},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
foot_serial_msgs__msg__RobotAttitude__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *foot_serial_msgs__msg__RobotAttitude__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
