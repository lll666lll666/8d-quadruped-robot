// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

#ifndef FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "foot_serial_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_foot_serial_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foot_serial_msgs, msg, RobotAttitude)();

#ifdef __cplusplus
}
#endif

#endif  // FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
