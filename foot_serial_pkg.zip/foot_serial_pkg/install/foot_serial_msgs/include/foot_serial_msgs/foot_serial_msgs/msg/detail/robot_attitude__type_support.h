// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "foot_serial_msgs/msg/robot_attitude.h"


#ifndef FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TYPE_SUPPORT_H_
#define FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "foot_serial_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_foot_serial_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  foot_serial_msgs,
  msg,
  RobotAttitude
)(void);

#ifdef __cplusplus
}
#endif

#endif  // FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TYPE_SUPPORT_H_
