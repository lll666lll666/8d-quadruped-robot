// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

#ifndef FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TYPE_SUPPORT_HPP_
#define FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "foot_serial_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_foot_serial_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  foot_serial_msgs,
  msg,
  RobotAttitude
)();
#ifdef __cplusplus
}
#endif

#endif  // FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__TYPE_SUPPORT_HPP_
