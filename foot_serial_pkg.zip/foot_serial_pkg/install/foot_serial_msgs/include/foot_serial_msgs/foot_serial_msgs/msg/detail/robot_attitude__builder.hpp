// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from foot_serial_msgs:msg/RobotAttitude.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "foot_serial_msgs/msg/robot_attitude.hpp"


#ifndef FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__BUILDER_HPP_
#define FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "foot_serial_msgs/msg/detail/robot_attitude__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace foot_serial_msgs
{

namespace msg
{

namespace builder
{

class Init_RobotAttitude_yaw
{
public:
  explicit Init_RobotAttitude_yaw(::foot_serial_msgs::msg::RobotAttitude & msg)
  : msg_(msg)
  {}
  ::foot_serial_msgs::msg::RobotAttitude yaw(::foot_serial_msgs::msg::RobotAttitude::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return std::move(msg_);
  }

private:
  ::foot_serial_msgs::msg::RobotAttitude msg_;
};

class Init_RobotAttitude_pitch
{
public:
  explicit Init_RobotAttitude_pitch(::foot_serial_msgs::msg::RobotAttitude & msg)
  : msg_(msg)
  {}
  Init_RobotAttitude_yaw pitch(::foot_serial_msgs::msg::RobotAttitude::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_RobotAttitude_yaw(msg_);
  }

private:
  ::foot_serial_msgs::msg::RobotAttitude msg_;
};

class Init_RobotAttitude_roll
{
public:
  Init_RobotAttitude_roll()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotAttitude_pitch roll(::foot_serial_msgs::msg::RobotAttitude::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_RobotAttitude_pitch(msg_);
  }

private:
  ::foot_serial_msgs::msg::RobotAttitude msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::foot_serial_msgs::msg::RobotAttitude>()
{
  return foot_serial_msgs::msg::builder::Init_RobotAttitude_roll();
}

}  // namespace foot_serial_msgs

#endif  // FOOT_SERIAL_MSGS__MSG__DETAIL__ROBOT_ATTITUDE__BUILDER_HPP_
