// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FOOT_SERIAL_MSGS__MSG__ROBOT_ATTITUDE_HPP_
#define FOOT_SERIAL_MSGS__MSG__ROBOT_ATTITUDE_HPP_

#include "foot_serial_msgs/msg/detail/robot_attitude__struct.hpp"
#include "foot_serial_msgs/msg/detail/robot_attitude__builder.hpp"
#include "foot_serial_msgs/msg/detail/robot_attitude__traits.hpp"
#include "foot_serial_msgs/msg/detail/robot_attitude__type_support.hpp"

#endif  // FOOT_SERIAL_MSGS__MSG__ROBOT_ATTITUDE_HPP_
