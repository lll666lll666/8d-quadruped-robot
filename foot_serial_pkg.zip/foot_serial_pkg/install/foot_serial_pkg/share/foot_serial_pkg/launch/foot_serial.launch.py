from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='foot_serial_pkg',
            executable='foot_trajectory_publisher',
            name='foot_trajectory_publisher',
            output='screen',
            parameters=[
                {
                    'topic_fl': '/foot_position_fl',
                    'topic_fr': '/foot_position_fr',
                    'topic_rl': '/foot_position_rl',
                    'topic_rr': '/foot_position_rr',
                    'publish_rate_hz': 200.0,
                    'joystick_topic': '/joystick_cmd',
                    'mode_topic': '/motion_mode',
                    'enable_joystick_control': True,
                    'turn_gain': 0.7,
                    'Ts': 0.5,
                    'lambda_ratio': 0.5,
                    'h': -15.0,
                    'xs': 0.0,
                    'xf': 0.0,
                    'zs': 100.0,
                }
            ],
        ),
        Node(
            package='foot_serial_pkg',
            executable='joystick_command_node',
            name='joystick_command_node',
            output='screen',
            parameters=[
                {
                    'joystick_topic': '/joystick_cmd',
                    'mode_topic': '/motion_mode',
                    'publish_rate_hz': 200.0,
                    'axis_left_x': 0,
                    'axis_left_y': 1,
                    'deadzone': 0.05,
                    # PS2 常见键位：GREEN(三角)=4，BLUE(叉)=0
                    'button_green': 4,
                    'button_blue': 0,
                }
            ],
        ),
        Node(
            package='foot_serial_pkg',
            executable='imu_stabilizer_node',
            name='imu_stabilizer_node',
            output='screen',
            parameters=[
                {
                    'attitude_topic': '/attitude',
                    'mode_topic': '/motion_mode',
                    'topic_fl': '/foot_position_fl',
                    'topic_fr': '/foot_position_fr',
                    'topic_rl': '/foot_position_rl',
                    'topic_rr': '/foot_position_rr',
                    'publish_rate_hz': 200.0,
                    'stand_x': 0.0,
                    'stand_z': 100.0,
                    'target_roll': -2.9,
                    'target_pitch': 1.0,
                    'z_min': 60.0,
                    'z_max': 140.0,
                    # 初始给保守参数，便于现场逐步加大
                    'roll_kp': 1.0,
                    'roll_ki': 0.1,
                    'roll_kd': 0.08,
                    'pitch_kp': 1.0,
                    'pitch_ki': 0.1,
                    'pitch_kd': 0.08,
                    'integral_limit': 30.0,
                    'max_axis_correction': 20.0,
                }
            ],
        ),
        Node(
            package='foot_serial_pkg',
            executable='serial_bridge_node',
            name='serial_bridge_node',
            output='screen',
            parameters=[
                {
                    'topic_fl': '/foot_position_fl',
                    'topic_fr': '/foot_position_fr',
                    'topic_rl': '/foot_position_rl',
                    'topic_rr': '/foot_position_rr',
                    'serial_port': '/dev/ttyAMA0',
                    'baudrate': 115200,
                    'timeout': 0.02,    
                    'start_byte': 0xAA,
                    'flag_byte': 0x01,
                    'end_byte': 0x55,
                }
            ],
        ),
    ])
